#include <iostream>
#include <unordered_set>
#include <vector>

using namespace std;

class Graph {
public:
    int vertices;
    vector<unordered_set<int>> adjacencyList;

    Graph(int v) : vertices(v), adjacencyList(v) {}

    void addEdge(int v, int w) {
        adjacencyList[v].insert(w);
        adjacencyList[w].insert(v);  // Assuming an undirected graph
    }

    void DFS(int startVertex) {
        unordered_set<int> visited;
        recursiveDFS(startVertex, visited);
    }

private:
    void recursiveDFS(int currentVertex, unordered_set<int>& visited) {
        visited.insert(currentVertex);
        cout << currentVertex << " ";

        for (int neighbor : adjacencyList[currentVertex]) {
            if (visited.find(neighbor) == visited.end()) {
                recursiveDFS(neighbor, visited);
            }
        }
    }
};

int main() {
    // Example graph
    Graph graph(6);
    graph.addEdge(0, 1);
    graph.addEdge(0, 2);
    graph.addEdge(1, 3);
    graph.addEdge(2, 4);
    graph.addEdge(2, 5);

    cout << "DFS starting from vertex 0: ";
    graph.DFS(0);

    return 0;
}


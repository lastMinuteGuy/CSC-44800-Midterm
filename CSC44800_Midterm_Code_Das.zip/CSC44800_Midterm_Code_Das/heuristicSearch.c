#include <iostream>
#include <vector>
#include <queue>
#include <cmath>

using namespace std;

struct Node {
    int x, y;
    double cost; // cost from start to this node
    double heuristic; // heuristic value (Euclidean distance to goal)
    double totalCost; // total cost = cost + heuristic
    Node* parent;

    Node(int x, int y) : x(x), y(y), cost(0), heuristic(0), totalCost(0), parent(nullptr) {}

    // Helper function to calculate Euclidean distance heuristic
    double calculateHeuristic(const Node& goal) const {
        return sqrt(pow(x - goal.x, 2) + pow(y - goal.y, 2));
    }
};

struct CompareNodes {
    bool operator()(const Node* a, const Node* b) const {
        // Compare nodes based on total cost (priority queue ordering)
        return a->totalCost > b->totalCost;
    }
};

// Function to perform A* search
vector<Node*> AStarSearch(Node* start, Node* goal, vector<vector<int>>& grid) {
    priority_queue<Node*, vector<Node*>, CompareNodes> openSet;
    vector<Node*> closedSet;

    start->heuristic = start->calculateHeuristic(*goal);
    start->totalCost = start->heuristic;
    openSet.push(start);

    while (!openSet.empty()) {
        Node* current = openSet.top();
        openSet.pop();

        if (current == goal) {
            // Reconstruct path
            vector<Node*> path;
            while (current != nullptr) {
                path.push_back(current);
                current = current->parent;
            }
            return path;
        }

        closedSet.push_back(current);

        // Define possible moves (up, down, left, right)
        const int moves[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

        for (const auto& move : moves) {
            int newX = current->x + move[0];
            int newY = current->y + move[1];

            // Check if the new position is within the grid
            if (newX >= 0 && newX < grid.size() && newY >= 0 && newY < grid[0].size()) {
                // Check if the new position is an obstacle (assuming 0 represents an obstacle)
                if (grid[newX][newY] == 0) {
                    continue;
                }

                // Create a new node for the neighbor
                Node* neighbor = new Node(newX, newY);
                neighbor->parent = current;
                neighbor->cost = current->cost + 1; // Assuming cost of moving between cells is 1
                neighbor->heuristic = neighbor->calculateHeuristic(*goal);
                neighbor->totalCost = neighbor->cost + neighbor->heuristic;

                // Check if the neighbor is already in the closed set
                auto it = find_if(closedSet.begin(), closedSet.end(), [neighbor](const Node* n) {
                    return n->x == neighbor->x && n->y == neighbor->y;
                });

                if (it != closedSet.end()) {
                    delete neighbor;
                    continue;
                }

                // Check if the neighbor is already in the open set
                it = find_if(openSet.cbegin(), openSet.cend(), [neighbor](const Node* n) {
                    return n->x == neighbor->x && n->y == neighbor->y;
                });

                if (it == openSet.cend()) {
                    openSet.push(neighbor);
                } else {
                    // If the neighbor is in the open set and the new path is better, update it
                    if (neighbor->totalCost < (*it)->totalCost) {
                        openSet.push(neighbor);
                    } else {
                        delete neighbor;
                    }
                }
            }
        }
    }

    // If the open set is empty and the goal is not reached, return an empty path
    return vector<Node*>();
}

int main() {
    // Example grid (1 represents a valid cell, 0 represents an obstacle)
    vector<vector<int>> grid = {
        {1, 1, 1, 1, 1},
        {1, 0, 1, 0, 1},
        {1, 1, 1, 1, 1},
        {0, 0, 1, 0, 1},
        {1, 1, 1, 1, 1}
    };

    Node start(0, 0);
    Node goal(4, 4);

    vector<Node*> path = AStarSearch(&start, &goal, grid);

    if (path.empty()) {
        cout << "No path found." << endl;
    } else {
        cout << "Path found:" << endl;
        for (auto it = path.rbegin(); it != path.rend(); ++it) {
            cout << "(" << (*it)->x << ", " << (*it)->y << ") ";
        }
        cout << endl;
    }

    // Clean up allocated nodes
    for (auto node : path) {
        delete node;
    }

    return 0;
}

